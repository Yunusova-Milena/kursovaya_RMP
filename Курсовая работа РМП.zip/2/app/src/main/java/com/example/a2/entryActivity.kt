package com.example.a2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent
import androidx.core.content.ContextCompat

class entryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entry)

        val button3: Button = findViewById(R.id.button3)
        val button4: Button = findViewById(R.id.button4)
        button3.setTextColor(ContextCompat.getColor(this, R.color.white))
        button4.setTextColor(ContextCompat.getColor(this, R.color.white))

        // обработчик нажатия на кнопку
        button3.setOnClickListener {
            // Intent для перехода в LoginActivity
            val intent = Intent(this, MainActivity::class.java)
            // Запускаем
            startActivity(intent)
        }
        button4.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)

            startActivity(intent)
        }
    }

}