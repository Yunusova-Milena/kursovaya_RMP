package com.example.a2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class OrdersFragmentmanic : Fragment() {

    private lateinit var materialRecyclerView: RecyclerView
    private lateinit var materialAdapter: ManicAdapter
    private lateinit var materialList: ArrayList<Manic>
    private lateinit var databaseReference: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_master_orders, container, false)

        // Получаем ссылку на базу данных Firebase
        databaseReference = FirebaseDatabase.getInstance().reference.child("Manic")

        // Найти RecyclerView в макете фрагмента
        materialRecyclerView = view.findViewById(R.id.priborsM)

        materialRecyclerView.layoutManager = LinearLayoutManager(context)
        materialRecyclerView.setHasFixedSize(true)

        materialList = arrayListOf()

        materialAdapter = ManicAdapter(materialList, databaseReference)

        materialRecyclerView.adapter = materialAdapter

        readProductsFromFirebase()

        return view
    }

    private fun readProductsFromFirebase() {
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (productSnapshot in dataSnapshot.children) {
                    val name = productSnapshot.child("name").getValue(String::class.java) ?: ""
                    val quantity = productSnapshot.child("quantity").getValue(Int::class.java) ?: 0
                    val price = productSnapshot.child("price").getValue(Int::class.java) ?: 0
                    val expirationDate = productSnapshot.child("expirationDate").getValue(String::class.java) ?: ""
                    val image = productSnapshot.child("image").getValue(String::class.java) ?: ""
                    val material = Manic(name, quantity, price, expirationDate, image)
                    materialList.add(material)
                }
                materialAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(databaseError: DatabaseError) {

            }
        })
    }
}
