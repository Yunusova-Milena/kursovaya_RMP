package com.example.a2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.DatabaseReference

class MaterialAdapter(private val materialList: ArrayList<Material>, private val databaseReference: DatabaseReference) : RecyclerView.Adapter<MaterialAdapter.MaterialViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MaterialViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_material, parent, false)
        return MaterialViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MaterialViewHolder, position: Int) {
        val currentItem = materialList[position]

        holder.itemName.text = currentItem.name
        holder.itemQuantity.setText(currentItem.quantity.toString())

        // Загрузка изображения из Firebase
        Glide.with(holder.itemView)
            .load(currentItem.image)
            .into(holder.itemImage)

        holder.minusBtn.setOnClickListener {
            if (currentItem.quantity > 0) {
                // Уменьшаем количество в приложении
                currentItem.quantity--
                holder.itemQuantity.setText(currentItem.quantity.toString()) // Обновляем отображение в EditText

                // Обновляем значение в Firebase
                databaseReference.child(currentItem.name).child("quantity").setValue(currentItem.quantity)

                if (currentItem.quantity == 0) {
                    // Удаляем элемент из списка и Firebase
                    removeItem(position)
                }
            }
        }
    }

    override fun getItemCount() = materialList.size

    private fun removeItem(position: Int) {
        val itemToRemove = materialList[position]
        materialList.removeAt(position)
        notifyItemRemoved(position)

        // Удаляем элемент из Firebase
        databaseReference.child(itemToRemove.name).removeValue()
    }

    class MaterialViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemImage: ImageView = itemView.findViewById(R.id.itemImage)
        val itemName: TextView = itemView.findViewById(R.id.itemName)
        val itemQuantity: EditText = itemView.findViewById(R.id.itemQuantity)
        val minusBtn: ImageButton = itemView.findViewById(R.id.minusBtn)
    }
}
