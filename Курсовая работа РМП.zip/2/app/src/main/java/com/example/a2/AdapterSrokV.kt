package com.example.a2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.DatabaseReference

class AdapterSrokV(private val materialList6: ArrayList<Vizajj>, private val databaseReference: DatabaseReference) : RecyclerView.Adapter<AdapterSrokV.VizajViewHoldersrok>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VizajViewHoldersrok {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_srok, parent, false)
        return VizajViewHoldersrok(itemView)
    }

    override fun onBindViewHolder(holder: VizajViewHoldersrok, position: Int) {
        val currentItem = materialList6[position]

        holder.itemName.text = currentItem.name
        // holder.itemQuantity.setText(currentItem.quantity.toString())

        Glide.with(holder.itemView)
            .load(currentItem.image)
            .into(holder.itemImage)

        holder.delBtn.setOnClickListener {
            // Удаление записи из Firebase
            databaseReference.child(currentItem.name).removeValue()

            // Удаление записи из списка и обновление RecyclerView
            materialList6.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, materialList6.size)
        }
    }

    override fun getItemCount() = materialList6.size

    class VizajViewHoldersrok(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemImage: ImageView = itemView.findViewById(R.id.itemImage)
        val itemName: TextView = itemView.findViewById(R.id.itemName)
        // val itemQuantity: EditText = itemView.findViewById(R.id.itemQuantity)
        val delBtn: ImageButton = itemView.findViewById(R.id.delBtn)
    }
}