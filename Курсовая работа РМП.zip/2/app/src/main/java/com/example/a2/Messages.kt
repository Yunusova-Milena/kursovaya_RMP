package com.example.a2

data class Messages(
    val message: String = "",
   // val readByAdmin: Boolean
)
