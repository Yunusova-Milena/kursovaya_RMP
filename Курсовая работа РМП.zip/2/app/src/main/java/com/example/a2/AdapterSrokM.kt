package com.example.a2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.DatabaseReference

class AdapterSrokM(private val materialList5: ArrayList<Manic>, private val databaseReference: DatabaseReference) : RecyclerView.Adapter<AdapterSrokM.ManicViewHoldersrok>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ManicViewHoldersrok {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_srok, parent, false)
        return ManicViewHoldersrok(itemView)
    }

    override fun onBindViewHolder(holder: ManicViewHoldersrok, position: Int) {
        val currentItem = materialList5[position]

        holder.itemName.text = currentItem.name
        // holder.itemQuantity.setText(currentItem.quantity.toString())

        // Загрузка изображения из Firebase
        Glide.with(holder.itemView)
            .load(currentItem.image)
            .into(holder.itemImage)

        holder.delBtn.setOnClickListener {
            // Удаление записи из Firebase
            databaseReference.child(currentItem.name).removeValue()

            // Удаление записи из списка и обновление RecyclerView
            materialList5.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, materialList5.size)
        }
    }





    override fun getItemCount() = materialList5.size

    class ManicViewHoldersrok(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemImage: ImageView = itemView.findViewById(R.id.itemImage)
        val itemName: TextView = itemView.findViewById(R.id.itemName)
        // val itemQuantity: EditText = itemView.findViewById(R.id.itemQuantity)
        val delBtn: ImageButton = itemView.findViewById(R.id.delBtn)
    }
}