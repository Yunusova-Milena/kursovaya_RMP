package com.example.a2
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class MasterMessageFragment : Fragment() {
    private lateinit var messageEditText: EditText
    private lateinit var sendButton: Button
    private lateinit var database: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_master_message, container, false)
        messageEditText = view.findViewById(R.id.editTextMessage)
        sendButton = view.findViewById(R.id.buttonSend)
        database = FirebaseDatabase.getInstance().reference.child("messages")

        sendButton.setOnClickListener {
            val messageText = messageEditText.text.toString()
            sendMessage(messageText)
            messageEditText.setText("") // Очищаем поле ввода после отправки

            // Показываем toast
            val toast = Toast(requireContext())
            val layoutInflater = layoutInflater.inflate(R.layout.toast_layout, view.findViewById(R.id.toast_root))
            toast.duration = Toast.LENGTH_LONG
            toast.view = layoutInflater
            toast.show()
        }
        return view
    }

    private fun sendMessage(messageText: String) {
        val newMessage = mapOf("message" to "Сделай заказ: $messageText")
        database.child(messageText).setValue(newMessage)
    }
}
