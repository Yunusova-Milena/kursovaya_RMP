package com.example.a2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError

class AdminMessageAdapter(private val materialList10: ArrayList<Messages>, private val databaseReference: DatabaseReference) : RecyclerView.Adapter<AdminMessageAdapter.AdminMessageViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdminMessageViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_message, parent, false)
        return AdminMessageViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: AdminMessageViewHolder, position: Int) {
        val currentItem = materialList10[position]
        holder.messagesTextView.text = currentItem.message

        holder.readBtn.setTextColor(ContextCompat.getColor(holder.readBtn.context, R.color.white))


        holder.readBtn.setOnClickListener {
            val messageText = currentItem.message // Получаем текст сообщения
            val query = databaseReference.orderByChild("message").equalTo(messageText)
            query.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    for (snapshot in dataSnapshot.children) {
                        snapshot.ref.removeValue() // Удаляем сообщение из базы данных
                    }

                }

                override fun onCancelled(databaseError: DatabaseError) {

                }
            })

            // Удаление записи из списка и обновление RecyclerView
            materialList10.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, materialList10.size)
        }

    }

    override fun getItemCount() = materialList10.size

    class AdminMessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val messagesTextView: TextView = itemView.findViewById(R.id.messagesTextView)
        val readBtn: Button = itemView.findViewById(R.id.readBtn)
    }
}
