package com.example.a2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.PercentFormatter
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import com.google.firebase.database.*
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.PieEntry

class PieChartFragment : Fragment() {

    private lateinit var pieChart: PieChart
    private var paricTotal = 0
    private var vizajTotal = 0
    private var manicTotal = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_pie_chart, container, false)

        pieChart = view.findViewById(R.id.PieChart)

        val databaseReference9 = FirebaseDatabase.getInstance().reference

        // Читаем данные из Firebase и строим диаграмму
        readProductsFromFirebase(databaseReference9)

        return view
    }

    private fun readProductsFromFirebase(databaseReference: DatabaseReference) {
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                paricTotal = calculateTotalValue(dataSnapshot.child("Paric"))
                vizajTotal = calculateTotalValue(dataSnapshot.child("Vizaj"))
                manicTotal = calculateTotalValue(dataSnapshot.child("Manic"))

                // Данные для диаграммы
                val entries = ArrayList<PieEntry>()
                entries.add(PieEntry(paricTotal.toFloat(), "Парикмахер"))
                entries.add(PieEntry(vizajTotal.toFloat(), "Визажист"))
                entries.add(PieEntry(manicTotal.toFloat(), "Маникюр"))

                val dataSet = PieDataSet(entries, "Общая стоимость товаров")

                val colors = listOf(
                    ContextCompat.getColor(requireContext(), R.color.pink3),
                    ContextCompat.getColor(requireContext(), R.color.pink2),
                    ContextCompat.getColor(requireContext(), R.color.pink)
                )

                // Настройка внешнего вида диаграммы
                dataSet.colors = colors
                dataSet.valueFormatter = PercentFormatter(pieChart)
                dataSet.valueTextSize = 12f
                dataSet.valueTextColor = ContextCompat.getColor(requireContext(), R.color.white) // Задаем белый цвет текста значений
                dataSet.sliceSpace = 3f

                val pieData = PieData(dataSet)
                pieChart.data = pieData
                pieChart.description.isEnabled = false
                pieChart.setUsePercentValues(true)
                pieChart.animateY(1000)
                pieChart.legend.isEnabled = false // Убираем метки снизу диаграммы
                pieChart.invalidate()

                pieChart.setOnChartValueSelectedListener(object : OnChartValueSelectedListener {
                    override fun onValueSelected(e: Entry?, h: Highlight?) {
                        e?.let {
                            val label = (it as PieEntry).label
                            val totalSpent = when (label) {
                                "Парикмахер" -> paricTotal
                                "Визажист" -> vizajTotal
                                "Маникюр" -> manicTotal
                                else -> 0
                            }
                            showCustomToast("Общая стоимость для $label: $totalSpent")
                        }
                    }

                    override fun onNothingSelected() {

                    }
                })
            }

            override fun onCancelled(databaseError: DatabaseError) {

            }
        })
    }

    private fun calculateTotalValue(masterNode: DataSnapshot): Int {
        var totalValue = 0
        for (productSnapshot in masterNode.children) {
            val quantity = productSnapshot.child("quantity").getValue(Int::class.java) ?: 0
            val price = productSnapshot.child("price").getValue(Int::class.java) ?: 0
            totalValue += quantity * price
        }
        return totalValue
    }

    private fun showCustomToast(message: String) {
        val inflater = layoutInflater
        val layout: View = inflater.inflate(
            R.layout.toast_custom,
            view?.findViewById(R.id.toast_root)
        )

        val text: TextView = layout.findViewById(R.id.toast_text)
        text.text = message

        with (Toast(context)) {
            duration = Toast.LENGTH_LONG
            view = layout
            show()
        }
    }
}
