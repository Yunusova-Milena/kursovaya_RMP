package com.example.a2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.example.a2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    companion object {
        const val TAG = "FirebaseAuth"
        private const val RC_SIGN_IN = 9001
    }

    // для входа через Google
    private lateinit var googleSignInClient: GoogleSignInClient

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        // для входа через Google
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)


        binding.loginButton.setOnClickListener {
            if (with(binding) { editTextEmail.text.isBlank() || editTextPassword.text.isBlank() })
                return@setOnClickListener
            auth.signInWithEmailAndPassword(
                binding.editTextEmail.text.toString(),
                binding.editTextPassword.text.toString()
            )
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        toast("Login success")
                        startAppropriateActivity()
                    } else {
                        toast("Login failed")
                    }
                }
        }
        binding.loginButton.setTextColor(ContextCompat.getColor(this, R.color.white))
    }

    override fun onStart() {
        super.onStart()
        auth.signOut()
        val currentUser = auth.currentUser
        if (currentUser != null) {
            startAppropriateActivity()
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            if (task.isSuccessful) {
                val account = task.result
                firebaseAuthWithGoogle(account)
            } else {
                Log.w(TAG, "Google sign in failed", task.exception)
                Toast.makeText(this, "Google sign in failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun firebaseAuthWithGoogle(acct: GoogleSignInAccount?) {
        val credential = GoogleAuthProvider.getCredential(acct?.idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "signInWithCredential:success")
                    startAppropriateActivity()
                } else {
                    Log.w(TAG, "signInWithCredential:failure", task.exception)
                    Toast.makeText(this, "Authentication failed", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun startAppropriateActivity() {
        val currentUser = auth.currentUser
        val email = currentUser?.email

        if (email != null) {
            when {
                email == "admin@example.com" -> {
                    val intent = Intent(this@MainActivity, AdminNavigationActivity::class.java)
                    startActivity(intent)
                }
                email == "manic@example.com" -> {
                    val intent = Intent(this@MainActivity, ManicActivity::class.java)
                    startActivity(intent)
                }
                email == "vizaj@example.com" -> {
                    val intent = Intent(this@MainActivity, VizajActivity::class.java)
                    startActivity(intent)
                }
                else -> {
                    val intent = Intent(this@MainActivity, MasterNavigationActivity::class.java)
                    startActivity(intent)
                }
            }
            finish() // закрываем текущую активность после перехода
        } else {
            toast("No user is signed in")
        }
    }

    override fun onBackPressed() {
        auth.signOut()
        super.onBackPressed()
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }
}
