package com.example.a2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DatabaseReference

class PriemAdapter (private val materialList2: ArrayList<Priem>) : RecyclerView.Adapter<PriemAdapter.PriemViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PriemViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_priem, parent, false)
        return PriemViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: PriemViewHolder, position: Int) {
        val currentItem = materialList2[position]

        holder.itemName2.text = currentItem.name

        holder.priemBtn.setTextColor(ContextCompat.getColor(holder.priemBtn.context, R.color.white))

        holder.priemBtn.setOnClickListener {
            val master = currentItem.master // Получаем название таблицы из строки master

            // Определяем таблицу в зависимости от значения master
            val databaseReference1: DatabaseReference = when (master) {
                "Paric" -> FirebaseDatabase.getInstance().reference.child("Paric")
                "Vizaj" -> FirebaseDatabase.getInstance().reference.child("Vizaj")
                "Manic" -> FirebaseDatabase.getInstance().reference.child("Manic")
                else -> {
                    return@setOnClickListener
                }
            }

            val priem = HashMap<String, Any>()
            priem["name"] = currentItem.name
            priem["quantity"] = currentItem.quantity.toInt()
            priem["price"] = currentItem.price.toInt()
            priem["expirationDate"] = currentItem.expirationDate
            // ...

            when (currentItem.name) {
                "Шампунь" -> priem["image"] = "https://firebasestorage.googleapis.com/v0/b/salon-10c31.appspot.com/o/shampun.png?alt=media&token=c365e870-138a-4f2d-a5db-1c8ab8cac15e"
                "Коричневая тушь" -> priem["image"] = "https://firebasestorage.googleapis.com/v0/b/salon-10c31.appspot.com/o/tush.png?alt=media&token=56653fe3-8219-49df-849c-0fdf9823a1b5"
                "Кондиционер" -> priem["image"] = "https://firebasestorage.googleapis.com/v0/b/salon-10c31.appspot.com/o/kondis.png?alt=media&token=456a7e7a-13d9-45a1-a3c8-f44d2442aed1"
                "Баф" -> priem["image"] = "https://firebasestorage.googleapis.com/v0/b/salon-10c31.appspot.com/o/%D0%B1%D0%B0%D1%84%D1%84.jpg?alt=media&token=12c1d050-4890-489e-adf8-dba3b2bf2b39"

            }

            val ordersRef = FirebaseDatabase.getInstance().reference.child("orders")
            ordersRef.child(currentItem.name).removeValue()

            val newPriemRef =
                databaseReference1.child(currentItem.name) // Генерируем уникальный ключ для нового элемента
            newPriemRef.setValue(priem) // Сохраняем данные товара в соответствующую таблицу

            // Удаление строки из списка после успешной записи в Firebase
            materialList2.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, materialList2.size)
        }
    }
    override fun getItemCount() = materialList2.size

    class PriemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // val itemImage2: ImageView = itemView.findViewById(R.id.itemImage2)
        val itemName2: TextView = itemView.findViewById(R.id.itemName2)
        // val itemQuantity: EditText = itemView.findViewById(R.id.itemQuantity)
        val priemBtn: Button = itemView.findViewById(R.id.priemBtn)
    }
}
