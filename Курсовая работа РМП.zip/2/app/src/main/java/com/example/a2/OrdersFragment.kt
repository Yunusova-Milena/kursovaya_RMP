package com.example.a2
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import com.google.firebase.database.FirebaseDatabase
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.util.Calendar


class OrdersFragment : Fragment() {
    private lateinit var productNameEditText: EditText
    private lateinit var quantityEditText: EditText
    private lateinit var expiryDateEditText: EditText
    private lateinit var priceEditText: EditText
    private lateinit var masterEditText: EditText
    private lateinit var addButton: Button


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_order, container, false)

        productNameEditText = view.findViewById(R.id.productNameEditText)
        quantityEditText = view.findViewById(R.id.quantityEditText)
        expiryDateEditText = view.findViewById(R.id.expiryDateEditText)
        priceEditText = view.findViewById(R.id.priceEditText)
        masterEditText = view.findViewById(R.id.MasterEditText)


        // Настройка обработчика для выбора даты
        expiryDateEditText.setOnClickListener {
            showDatePickerDialog()
        }

        addButton = view.findViewById(R.id.addbutton1)
        addButton.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))

        addButton.setOnClickListener {
            saveOrderToFirebase()
        }

        return view
    }

    // Функция для отображения DatePickerDialog
    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, selectedYear, selectedMonth, selectedDay ->
                // Форматирование даты и установка текста в EditText
                val formattedDate = String.format("%02d-%02d-%04d", selectedDay, selectedMonth + 1, selectedYear)
                expiryDateEditText.setText(formattedDate)
            },
            year, month, day
        )

        datePickerDialog.show()
    }

    private fun saveOrderToFirebase() {

        val name = productNameEditText.text.toString().trim()
        val quantity = quantityEditText.text.toString().trim()
        val expirationDate = expiryDateEditText.text.toString().trim()
        val price = priceEditText.text.toString().trim()
        val master = masterEditText.text.toString().trim()


        val database = FirebaseDatabase.getInstance()
        // Получаем ссылку на узел для заказов
        val ordersRef = database.getReference("orders")

// Создаем объект данных для заказа
        val orderData = hashMapOf(
            "name" to name,
            "quantity" to quantity,
            "expirationDate" to expirationDate,
            "price" to price,
            "master" to master
        )

// Сохраняем данные в Firebase
        ordersRef.child(name).setValue(orderData)
            .addOnSuccessListener {
                // Очищаем EditText после сохранения данных
                productNameEditText.setText("")
                quantityEditText.setText("")
                expiryDateEditText.setText("")
                priceEditText.setText("")
                masterEditText.setText("")

                Toast.makeText(context, "Данные успешно сохранены", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {

                Toast.makeText(context, "Ошибка при сохранении данных", Toast.LENGTH_SHORT).show()
            }


    }
}