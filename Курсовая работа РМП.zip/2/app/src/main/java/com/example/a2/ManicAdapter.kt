package com.example.a2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.DatabaseReference

class ManicAdapter(private val materialList: ArrayList<Manic>, private val databaseReference: DatabaseReference) : RecyclerView.Adapter<ManicAdapter.ManicViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ManicViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_material, parent, false)
        return ManicViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ManicViewHolder, position: Int) {
        val currentItem = materialList[position]

        holder.itemName.text = currentItem.name
        holder.itemQuantity.setText(currentItem.quantity.toString())

        // Загрузка изображения из Firebase
        Glide.with(holder.itemView)
            .load(currentItem.image)
            .into(holder.itemImage)

        holder.minusBtn.setOnClickListener {
            if (currentItem.quantity > 0) {
                // Уменьшаем количество в приложении
                currentItem.quantity--
                holder.itemQuantity.setText(currentItem.quantity.toString())

                // Обновляем значение в Firebase
                databaseReference.child(currentItem.name).child("quantity").setValue(currentItem.quantity)
            }
        }



    }

    override fun getItemCount() = materialList.size

    class ManicViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemImage: ImageView = itemView.findViewById(R.id.itemImage)
        val itemName: TextView = itemView.findViewById(R.id.itemName)
        val itemQuantity: EditText = itemView.findViewById(R.id.itemQuantity)
        val minusBtn: ImageButton = itemView.findViewById(R.id.minusBtn)
    }
}