package com.example.a2

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class Vizajj(
    val name: String = "",
    var quantity: Int = 0,
    val price: Int = 0,
    val expirationDate: String = "",
    val image: String = "",
    val master: String = "",
    val id: String = ""
){
    fun isExpired(): Boolean {
        val expiration = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).parse(expirationDate)
        val today = Calendar.getInstance().time

        return expiration != null && expiration.before(today)
    }
}






