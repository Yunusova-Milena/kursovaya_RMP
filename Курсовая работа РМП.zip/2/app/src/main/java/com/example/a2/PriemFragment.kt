package com.example.a2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError

class PriemFragment : Fragment() {

    private lateinit var materialRecyclerView2: RecyclerView
    private lateinit var materialAdapter2: PriemAdapter
    private lateinit var materialList2: ArrayList<Priem>
    private lateinit var databaseReference2: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_priem, container, false)

        databaseReference2 = FirebaseDatabase.getInstance().reference.child("orders")

        materialRecyclerView2 = view.findViewById(R.id.priborsP)

        materialRecyclerView2.layoutManager = LinearLayoutManager(context)
        materialRecyclerView2.setHasFixedSize(true)

        materialList2 = arrayListOf()

        materialAdapter2 = PriemAdapter(materialList2)
        materialRecyclerView2.adapter = materialAdapter2

        readProductsFromFirebase()

        return view
    }

    private fun readProductsFromFirebase() {
        databaseReference2.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (productSnapshot in dataSnapshot.children) {
                    val name = productSnapshot.child("name").getValue(String::class.java) ?: ""
                    val quantity = productSnapshot.child("quantity").getValue(String::class.java) ?: ""
                    val price = productSnapshot.child("price").getValue(String::class.java) ?: ""
                    val expirationDate = productSnapshot.child("expirationDate").getValue(String::class.java) ?: ""
                    val master = productSnapshot.child("master").getValue(String::class.java) ?: ""

                    //val image = productSnapshot.child("image").getValue(String::class.java) ?: ""
                    val priem = Priem(name, quantity, price, expirationDate, master)
                    materialList2.add(priem)
                }
                materialAdapter2.notifyDataSetChanged()
            }

            override fun onCancelled(databaseError: DatabaseError) {

            }
        })
    }
}