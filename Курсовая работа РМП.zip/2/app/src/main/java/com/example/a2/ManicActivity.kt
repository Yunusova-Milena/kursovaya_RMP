package com.example.a2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentTransaction
import com.google.android.material.bottomnavigation.BottomNavigationView

class ManicActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.master_navagation_layout)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationViewM)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.ordersMenuItemM -> {
                    // Открываем фрагмент с заказами
                    val masterordersFragment = OrdersFragmentmanic()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerM, masterordersFragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                    true
                }

                R.id.notificationsMenuItemM -> {
                    // Обработка навигации по уведомлениям
                    val srokFragmentt = MFragment()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerM, srokFragmentt)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                    true
                }


                R.id.MessageMenu -> {
                    // Обработка навигации по сообщениям
                    val srokFragment = MasterMessageFragment()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerM, srokFragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                    true
                }
                else -> false
            }
        }
    }
}
