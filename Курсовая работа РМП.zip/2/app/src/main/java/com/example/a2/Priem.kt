package com.example.a2

data class Priem(
    val name: String = "",
    val quantity: String = "",
    val price: String = "",
    val expirationDate: String = "",
    val master: String = "",
    val image: String = "",
    val id: String =""
)
