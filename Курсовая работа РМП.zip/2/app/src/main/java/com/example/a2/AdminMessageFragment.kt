package com.example.a2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class AdminMessageFragment : Fragment() {

    private lateinit var messageRecyclerView: RecyclerView
    private lateinit var messageAdapter: AdminMessageAdapter
    private lateinit var messageList10: ArrayList<Messages>
    private lateinit var databaseReference10: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_admin_message, container, false)

        // Получаем ссылку на базу данных Firebase
        databaseReference10 = FirebaseDatabase.getInstance().reference.child("messages")

        messageRecyclerView = view.findViewById(R.id.messageRecyclerView)

        messageRecyclerView.layoutManager = LinearLayoutManager(context)
        messageRecyclerView.setHasFixedSize(true)

        messageList10 = arrayListOf()

        messageAdapter = AdminMessageAdapter(messageList10, databaseReference10)

        messageRecyclerView.adapter = messageAdapter

        // Получить данные из Firebase и добавить их в RecyclerView
        readMessagesFromFirebase()

        return view
    }

    // Метод для чтения сообщений из Firebase
    private fun readMessagesFromFirebase() {
        databaseReference10.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                messageList10.clear() // Очистите список перед добавлением

                for (messageSnapshot in dataSnapshot.children) {
                    //val messageId = messageSnapshot.key ?: ""
                    val message = messageSnapshot.child("message").getValue(String::class.java) ?: ""
                    //val readByAdmin = messageSnapshot.child("readByAdmin").getValue(Boolean::class.java) ?: false
                    val messageItem = Messages(message)

                    messageList10.add(messageItem)
                }
                messageAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(databaseError: DatabaseError) {

            }
        })
    }
}
