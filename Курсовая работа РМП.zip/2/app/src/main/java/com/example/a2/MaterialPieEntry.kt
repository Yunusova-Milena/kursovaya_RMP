package com.example.a2

import com.github.mikephil.charting.data.PieEntry

class MaterialPieEntry(value: Float, val materialName: String, val totalCost: Int) : PieEntry(value) {
    override fun getLabel(): String {
        return "$materialName ($totalCost)"
    }
}

