package com.example.a2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentTransaction
import com.google.android.material.bottomnavigation.BottomNavigationView

class AdminNavigationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.admin_navigation_layout)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.ordersMenuItem -> {
                    // Открываем фрагмент с заказами
                    val ordersFragment = OrdersFragment()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, ordersFragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                    true
                }
                R.id.materialsMenuItem -> {
                    // Обработка навигации по материалам
                    val priemFragment = PriemFragment()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, priemFragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                    true
                }
                R.id.financesMenuItem -> {
                    // Обработка навигации по финансам
                    val pieFragment = PieChartFragment()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, pieFragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                    true
                }
                R.id.notificationsMenuItem -> {
                    // Обработка навигации по сообщениям
                    val yvedFragment = AdminMessageFragment()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, yvedFragment)
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit()
                    true
                }
                else -> false
            }
        }
    }
}
